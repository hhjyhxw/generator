package com.zhumeng.generator.common.constant;

/**
 * ${DESCRIPTION}
 *
 * @create 2017-06-14 8:36
 */
public class UserConstant {
    public static int PW_ENCORDER_SALT = 12;
}
